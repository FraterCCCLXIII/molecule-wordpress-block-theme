<?php
/**
 * Title: Hero Section 7
 * Slug: shadcn/hero-section-7
 * Categories: shadcn, shadcn-banner
 * Description: A hero section with title, description, and call-to-action buttons.
 */

?>
<!-- wp:group {"metadata":{"categories":["shadcn","shadcn-banner"],"patternName":"shadcn/hero-section-7","name":"Hero Section 7"},"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|9","bottom":"var:preset|spacing|9"}}}} -->
<div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--9);padding-bottom:var(--wp--preset--spacing--9)"><!-- wp:group {"className":"container has-text-align-center"} -->
<div class="wp-block-group container has-text-align-center"><!-- wp:group {"className":"mx-auto","style":{"spacing":{"blockGap":"var:preset|spacing|6"}},"layout":{"type":"constrained","contentSize":"1024px"}} -->
<div class="wp-block-group mx-auto"><!-- wp:heading {"level":1,"className":"lg:text-6xl"} -->
<h1 class="wp-block-heading lg:text-6xl">A Collection of Components Built With Shadcn &amp; Tailwind</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"text-balance lg:text-lg","textColor":"muted-foreground"} -->
<p class="text-balance lg:text-lg has-muted-foreground-color has-text-color">Finely crafted components built with React, Tailwind and Shadcn UI.<br>Developers can copy and paste these blocks directly into their project.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Discover all components</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:group {"className":"mx-auto mt-10 w-fit sm:flex-row","style":{"spacing":{"blockGap":"0"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center"}} -->
<div class="wp-block-group mx-auto mt-10 w-fit sm:flex-row"><!-- wp:image {"width":"54px","height":"54px","scale":"cover","sizeSlug":"large","style":{"border":{"radius":"100px","width":"1px"}},"borderColor":"muted"} -->
<figure class="wp-block-image size-large is-resized has-custom-border"><img src="https://deifkwefumgah.cloudfront.net/shadcnblocks/block/avatar-1.webp" alt="" class="has-border-color has-muted-border-color" style="border-width:1px;border-radius:100px;object-fit:cover;width:54px;height:54px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"width":"54px","height":"54px","scale":"cover","sizeSlug":"large","style":{"border":{"radius":"100px","width":"1px"},"spacing":{"margin":{"left":"-16px"}}},"borderColor":"muted"} -->
<figure class="wp-block-image size-large is-resized has-custom-border" style="margin-left:-16px"><img src="https://deifkwefumgah.cloudfront.net/shadcnblocks/block/avatar-2.webp" alt="" class="has-border-color has-muted-border-color" style="border-width:1px;border-radius:100px;object-fit:cover;width:54px;height:54px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"width":"54px","height":"54px","scale":"cover","sizeSlug":"large","style":{"border":{"radius":"100px","width":"1px"},"spacing":{"margin":{"left":"-16px"}}},"borderColor":"muted"} -->
<figure class="wp-block-image size-large is-resized has-custom-border" style="margin-left:-16px"><img src="https://deifkwefumgah.cloudfront.net/shadcnblocks/block/avatar-3.webp" alt="" class="has-border-color has-muted-border-color" style="border-width:1px;border-radius:100px;object-fit:cover;width:54px;height:54px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"width":"54px","height":"54px","scale":"cover","sizeSlug":"large","style":{"border":{"radius":"100px","width":"1px"},"spacing":{"margin":{"left":"-16px"}}},"borderColor":"muted"} -->
<figure class="wp-block-image size-large is-resized has-custom-border" style="margin-left:-16px"><img src="https://deifkwefumgah.cloudfront.net/shadcnblocks/block/avatar-4.webp" alt="" class="has-border-color has-muted-border-color" style="border-width:1px;border-radius:100px;object-fit:cover;width:54px;height:54px"/></figure>
<!-- /wp:image -->

<!-- wp:image {"width":"54px","height":"54px","scale":"cover","sizeSlug":"large","style":{"border":{"radius":"100px","width":"1px"},"spacing":{"margin":{"left":"-16px"}}},"borderColor":"muted"} -->
<figure class="wp-block-image size-large is-resized has-custom-border" style="margin-left:-16px"><img src="https://deifkwefumgah.cloudfront.net/shadcnblocks/block/avatar-5.webp" alt="" class="has-border-color has-muted-border-color" style="border-width:1px;border-radius:100px;object-fit:cover;width:54px;height:54px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|muted-foreground"}}}},"textColor":"muted-foreground"} -->
<p class="has-muted-foreground-color has-text-color has-link-color">200+ reviews</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->