<?php
/**
 * Title: Header 1
 * Slug: shadcn/header-1
 * Categories: shadcn, header
 * Description: Molecule-inspired top nav with custom mobile drawer block, centered logo, and icon-link blocks.
 */
?>

<!-- wp:group {"className":"molecule-top-nav","layout":{"type":"constrained"}} -->
<div class="wp-block-group molecule-top-nav">
	<!-- wp:group {"align":"wide","className":"molecule-top-nav-inner","layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignwide molecule-top-nav-inner">
		<!-- wp:group {"className":"molecule-top-nav-mobile","layout":{"type":"grid","columnCount":3,"minimumColumnWidth":null}} -->
		<div class="wp-block-group molecule-top-nav-mobile">
			<!-- wp:group {"className":"molecule-top-nav-mobile-menu","layout":{"type":"flex","justifyContent":"left","verticalAlignment":"center"}} -->
			<div class="wp-block-group molecule-top-nav-mobile-menu">
				<!-- wp:molecule/mobile-drawer -->
				<!-- wp:navigation-link {"label":"Home","url":"/","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Catalog","url":"/shop","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Peptide Guide","url":"/peptide-guide","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Research","url":"/research","kind":"custom"} /-->
				<!-- /wp:molecule/mobile-drawer -->
			</div>
			<!-- /wp:group -->

			<!-- wp:group {"className":"molecule-top-nav-logo","layout":{"type":"flex","justifyContent":"center","verticalAlignment":"center"}} -->
			<div class="wp-block-group molecule-top-nav-logo">
				<!-- wp:site-logo {"width":149,"shouldSyncIcon":true} /-->
			</div>
			<!-- /wp:group -->

			<!-- wp:group {"className":"molecule-top-nav-icons","layout":{"type":"flex","justifyContent":"right","verticalAlignment":"center"}} -->
			<div class="wp-block-group molecule-top-nav-icons">
				<!-- wp:molecule/icon-link {"type":"search"} /-->
				<!-- wp:molecule/icon-link {"type":"account"} /-->
				<!-- wp:molecule/icon-link {"type":"cart"} /-->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"className":"molecule-top-nav-desktop","layout":{"type":"flex","justifyContent":"space-between","verticalAlignment":"center"}} -->
		<div class="wp-block-group molecule-top-nav-desktop">
			<!-- wp:group {"className":"molecule-top-nav-logo","layout":{"type":"flex","justifyContent":"left","verticalAlignment":"center"}} -->
			<div class="wp-block-group molecule-top-nav-logo">
				<!-- wp:site-logo {"width":149,"shouldSyncIcon":true} /-->
			</div>
			<!-- /wp:group -->

			<!-- wp:navigation {"openSubmenusOnClick":false,"className":"molecule-desktop-navigation","layout":{"type":"flex","justifyContent":"center"}} -->
				<!-- wp:navigation-link {"label":"Home","url":"/","kind":"custom"} /-->
				<!-- wp:navigation-link {"label":"Catalog","url":"/shop","kind":"custom"} /-->
				<!-- wp:navigation-submenu {"label":"Research","url":"/research","kind":"custom"} -->
					<!-- wp:navigation-link {"label":"Peptide Guide","url":"/peptide-guide","kind":"custom"} /-->
					<!-- wp:navigation-link {"label":"Research","url":"/research","kind":"custom"} /-->
				<!-- /wp:navigation-submenu -->
			<!-- /wp:navigation -->

			<!-- wp:group {"className":"molecule-top-nav-icons","layout":{"type":"flex","justifyContent":"right","verticalAlignment":"center"}} -->
			<div class="wp-block-group molecule-top-nav-icons">
				<!-- wp:molecule/icon-link {"type":"search"} /-->
				<!-- wp:molecule/icon-link {"type":"account"} /-->
				<!-- wp:woocommerce/mini-cart {"className":"molecule-header-cart"} /-->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
